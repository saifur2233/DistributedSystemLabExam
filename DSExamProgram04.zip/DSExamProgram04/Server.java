/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DSExamProgram04;

/**
 *
 * @author PC NET Computers
 */
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class Server {
	public static void main(String[] args) throws IOException{
		
		//Create a Server Socket
		ServerSocket serverSocket = new ServerSocket(3333);
        System.out.println("Server Started..");

        while (true) {
            Socket socket = serverSocket.accept(); //Listen for a connection:
            System.out.println("Client connected..");

            String ip=(((InetSocketAddress) socket.getRemoteSocketAddress()).getAddress()).toString().replace("/","");
            System.out.println("Connected Client Ip address: "+ip);
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
              
            try {
                //read from client...
                Object cMsg = ois.readObject();
                System.out.println("From Client: " + (String) cMsg);

                String serverMsg = (String) cMsg;
                //serverMsg = serverMsg.toUpperCase();

                //send to client..
                oos.writeObject(serverMsg);
              

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
		
}


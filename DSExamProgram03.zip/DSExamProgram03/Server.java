/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DSExamProgram03;

/**
 *
 * @author PC NET Computers
 */

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args) throws IOException{
		
		ServerSocket ss = new ServerSocket(9899);
		System.out.println("Server binded at "+ ((ss.getInetAddress()).getLocalHost()).getHostAddress() + ":9899");
		System.out.println("Waiting for Client.....");
		
		Socket socket = ss.accept(); //Listen for a connection
		
	}

}

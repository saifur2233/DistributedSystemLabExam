/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DSExamProgram03;

/**
 *
 * @author PC NET Computers
 */
import java.io.IOException;
import java.net.Socket;

public class Client {
	 public static void main(String[] args) throws IOException {
		 System.out.println("Client Started...");
		 Socket soc = new Socket("localhost",9899);
			
		 System.out.println("Client connected...");
		 
	 }

}

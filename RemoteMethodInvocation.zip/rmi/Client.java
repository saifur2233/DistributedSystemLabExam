/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmi;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;


public class Client {
    
    private Client(){
        
    }
    public static void main(String[] args) throws RemoteException {
       
try{
      // Getting the Reistry 
       Registry registry = LocateRegistry.getRegistry(1888);
        
       MessageRemote stub =(MessageRemote) registry.lookup("Hello hello");
       
       stub.msg();
    
}  catch(Exception e){
    System.out.println(e);
}     

    }
    
}

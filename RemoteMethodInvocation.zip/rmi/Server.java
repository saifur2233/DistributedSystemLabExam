/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rmi;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.server.*;
/**
 *
 * @author Fazle Rabbi
 */
public class Server extends  MessageExecute {
    public Server(){
        
    }


    
    public static void main(String[] args) throws AlreadyBoundException {
        try{
            
            MessageExecute ob = new MessageExecute();
          
            //here exporting the remote object to the stub
          // System.setProperty("java.rmi.server.hostname","localhost");
            

            
            MessageRemote stub = (MessageRemote) UnicastRemoteObject.exportObject(ob, 0);
            
           Registry rgsty = LocateRegistry.createRegistry(1888);
          rgsty.rebind("hello nothing", stub);
            
            Registry req = LocateRegistry.getRegistry(1888);
            //req.bind("hi server", stub);
            System.out.println("Server is ready");
        }
        catch(RemoteException e){
            System.out.println(e);
        }
    }
    
}

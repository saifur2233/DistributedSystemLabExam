package socketprogramming01;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args) throws IOException{
		
		ServerSocket ss = new ServerSocket(9899);
		System.out.println("Server binded at "+ ((ss.getInetAddress()).getLocalHost()).getHostAddress() + ":9899");
		System.out.println("Waiting for Client.....");
		
		Socket socket = ss.accept(); //Listen for a connection
		
	}

}
package socketprogramming01;

import java.io.IOException;
import java.net.Socket;

public class Client {
	 public static void main(String[] args) throws IOException {
		 System.out.println("Client Started...");
		 Socket soc = new Socket("localhost",9899);
			
		 System.out.println("Client connected...");
		 
	 }

}
